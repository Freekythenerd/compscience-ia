<?php
    // if you're seeing this file, then you have the wrong one. this is just for local testing purposes
    $host = "192.168.64.2";
    $uname = "ben";
    $pwd = "ben";
    $sql_db = "compsci-ia";
?>
