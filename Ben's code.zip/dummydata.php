<?php

$tnames = [
    "dan",
    "james",
    "jeremy",
    "marley",
    "jasper",
    "kate",
    "jasmine",
    "erica",
    "bill",
    "jesse",
    "natasha",
    "michaela",
    "isabella",
    "gareth",
    "will"
];
$snames = [
        "Adams",
        "Baker",
        "Clark",
        "Davis",
        "Evans",
        "Frank",
        "Ghosh",
        "Hills",
        "Irwin",
        "Jones",
        "Klein",
        "Lopez",
        "Mason",
        "Nalty",
        "Ochoa",
        "Patel",
        "Quinn",
        "Reily",
];

$usernames = [
    "elitegamer22",
    "teacherfriend12",
    "petalsandroses5",
    "rebeccasimmons",
    "refrigerator12",
    "johnnyfive01",
    "fuzzyfreud12",
    "franticlion14",
    "natalieS",
    "pondoD"
];
?>
