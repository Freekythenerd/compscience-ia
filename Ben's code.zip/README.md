compscience-ia

How to start database:
    Run XAMPP
    Start Apache and MySQL
    Click Admin on MySQL which will bring you to phpmyadmin
    Click on user accounts
    Create a user account with all privilages 
    Set the username and password on dbconnect.php to the user account you just created
    
    
    
