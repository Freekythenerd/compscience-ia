<!DOCTYPE html>
<html lang="en">
<title>yoooooooo</title>
<head>
    <link rel="stylesheet" href="css/bootstrap.css" />
    </head>
<body>
<?php include "header.php"; ?>
<p>This web application was designed to give teachers the ability to be able to manage their classes and students</p>
</body>
</html>